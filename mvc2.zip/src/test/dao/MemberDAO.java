package test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import test.vo.Member;

public class MemberDAO {
	private static MemberDAO memberDao = new MemberDAO();
	
	private MemberDAO() {
		
	}
	
	public static MemberDAO getInstance() {
		return memberDao;
	}
	public Connection connect()
	{
		Connection conn = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=UTC", "root", "cs1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public void memberInsert(Member member) {
		
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("insert into member values(?,?,?,?)");

			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPasswd());
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getMail());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public Member memberSearch(String id)
	{
		Member member = null;
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from member where id = ?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				member = new Member();
				member.setId(rs.getString(1));
				member.setPasswd(rs.getString(2));
				member.setName(rs.getString(3));
				member.setMail(rs.getString(4));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return member;
	}
}
