package test.service;

import test.dao.MemberDAO;
import test.vo.Member;

public class MemberService {

	private static MemberService service = new MemberService();
	
	public MemberDAO dao = MemberDAO.getInstance();
	
	private MemberService() {
		
	}
	
	public static MemberService getInstance() {
		return service;
	}
	public void memberInsert(Member member) {
		dao.memberInsert(member);
	}
}
