package test.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.service.MemberService;
import test.vo.Member;

public class MemberSearchController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("id");
		
		MemberService service = MemberService.getInstance();
		Member searchMember = service.memberSearch(id);
		
		req.setAttribute("member", searchMember);
		
		HttpUtil.forward(req, resp, "/result/memberSearchOutput.jsp");
	}

}
