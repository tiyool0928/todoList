package test.Service;

import test.DAO.BankDAO;
import test.DAO.MemberDAO;

public class BankService {
	private static BankService service = new BankService();
	private BankDAO dao = BankDAO.getInstance();
	
	private BankService() {}
	
	public static BankService getInstance() {
		return service;
	}
	public int deposit(String id,int money) {
		return dao.deposit(id,money);
	}
	public int withdraw(String id,int money) {
		return dao.withdraw(id,money);
	}
}
