package test.Service;

import java.util.ArrayList;

import test.DAO.MemberDAO;
import test.VO.Member;

public class MemberService {

	private static MemberService service = new MemberService();
	
	public MemberDAO dao = MemberDAO.getInstance();
	
	private MemberService() {
		
	}
	
	public static MemberService getInstance() {
		return service;
	}
	public void memberInsert(Member member) {
		dao.memberInsert(member);
	}
	public Member memberSearch(String id)
	{
		return dao.memberSearch(id);
		
	}
	public Member memberLogin(String id,String pwd)
	{
		return dao.memberLogin(id,pwd);
	}
	public void memberUpdate(Member member) {
		dao.memberUpdate(member);
	}
	public void memberDelete(String id) {
		dao.memberDelete(id);
	}
	public ArrayList<Member> memberList() {
		return dao.memberList();
	}
}
