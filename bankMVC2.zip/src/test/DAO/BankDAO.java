package test.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import test.VO.Member;

public class BankDAO {
	private static BankDAO dao = new BankDAO();
	private BankDAO() {}
	public static BankDAO getInstance()
	{
		return dao;
	}
	public Connection connect()
	{
		Connection conn = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=UTC", "root", "cs1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	public int deposit(String id, int money)
	{
		Member member = null;
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from account where id = ?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int gMoney = Integer.parseInt(rs.getString(2));
				money += gMoney;
				
				pstmt = con.prepareStatement("update account set money = ? where id= ?");
				pstmt.setString(1, money+"");
				pstmt.setString(2, id);
				
				pstmt.executeUpdate();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return money;
	}
	public int withdraw(String id, int money)
	{
		Member member = null;
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from account where id = ?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			int gMoney = Integer.parseInt(rs.getString(2));
			if(rs.next())
			{
				
				if(gMoney < money)
				{
					return -1;
				}
				gMoney -= money;
				
				pstmt = con.prepareStatement("update account set money = ? where id= ?");
				pstmt.setString(1, gMoney+"");
				pstmt.setString(2, id);
				
				pstmt.executeUpdate();
				
			}return gMoney;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return money;
	}
}












