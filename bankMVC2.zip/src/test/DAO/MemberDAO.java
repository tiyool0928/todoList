package test.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import test.DAO.MemberDAO;
import test.VO.Member;

public class MemberDAO {
	private static MemberDAO memberDao = new MemberDAO();
	
	private MemberDAO() {
		
	}
	
	public static MemberDAO getInstance() {
		return memberDao;
	}
	public Connection connect()
	{
		Connection conn = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?serverTimezone=UTC", "root", "cs1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public void memberInsert(Member member) {
		
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("insert into member values(?,?,?,?)");

			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPasswd());
			pstmt.setString(3, member.getName());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public Member memberSearch(String id)
	{
		Member member = null;
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from member where id = ?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				member = new Member();
				member.setId(rs.getString(1));
				member.setPasswd(rs.getString(2));
				member.setName(rs.getString(3));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return member;
	}
	public void memberUpdate(Member member)
	{
		Connection con = this.connect();
		
		try {
			PreparedStatement pstmt = con.prepareStatement("update member set passwd=?, name=?, email=? where id=?");

			pstmt.setString(4, member.getId());
			pstmt.setString(1, member.getPasswd());
			pstmt.setString(2, member.getName());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public Member memberLogin(String id,String pwd)
	{
		Member member = null;
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from member where id = ? and passwd = ?");
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				member = new Member();
				member.setId(rs.getString(1));
				member.setPasswd(rs.getString(2));
				member.setName(rs.getString(3));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return member;
	}
	
	public void memberDelete(String id)
	{
		Connection con = this.connect();
		
		try {
			PreparedStatement pstmt = con.prepareStatement("delete from member where id=?");

			pstmt.setString(1, id);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Member> memberList(){
		ArrayList<Member> list = new ArrayList<Member>();
		
		Member member = null;
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from member");
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				member = new Member();
				member.setId(rs.getString(1));
				member.setPasswd(rs.getString(2));
				member.setName(rs.getString(3));
				list.add(member);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
}





