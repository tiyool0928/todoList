package test.Controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FirstController extends HttpServlet{
	HashMap<String,Controller> list;
	
	public void init(ServletConfig config) throws ServletException{
		list = new HashMap<String,Controller>();
		list.put("/index.do", new IndexController());
		list.put("/deposit.do", new DepositController());
	}
	
	public void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
		String uri = req.getRequestURI();
		String cPath = req.getContextPath();
		String path = uri.substring(cPath.length());
		Controller c = list.get(path);
		c.execute(req, resp);
	}
}
