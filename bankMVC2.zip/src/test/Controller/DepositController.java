package test.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.Service.BankService;

public class DepositController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) {
		// TODO Auto-generated method stub
		int money = Integer.parseInt(req.getParameter("money"));
		HttpSession s = req.getSession();
		String id = (String)s.getAttribute("id");
		
		BankService service = BankService.getInstance();
		money = service.deposit(id, money);
		
		req.setAttribute("money", money);
		HttpUtil.forward(req, resp, "/result/depositOutput.jsp");
	}

}
