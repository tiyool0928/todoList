package test.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.Service.MemberService;
import test.VO.Member;


public class IndexController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) {
		// TODO Auto-generated method stub
		String id = req.getParameter("id");
		String pwd = req.getParameter("passwd");
		
		MemberService service = MemberService.getInstance();
		Member m = service.memberLogin(id,pwd);
		
		if(m == null) {
			req.setAttribute("error", "There is no id");
			HttpUtil.forward(req, resp, "index.jsp");
		}
		else if(m.getId().equals("admin"))
		{
			HttpUtil.forward(req, resp, "adminMain.jsp");
		}
		else {
			HttpSession s = req.getSession();
			s.setAttribute("id", id);
			HttpUtil.forward(req, resp, "main.jsp");
		}
	}

}
