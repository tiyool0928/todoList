package test.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import test.Service.BankService;
import test.Service.MemberService;
import test.VO.Member;

public class TransitController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) {
		// TODO Auto-generated method stub
		String rid = req.getParameter("id");
		int money = Integer.parseInt(req.getParameter("money"));
		HttpSession s = req.getSession();
		String id = (String)s.getAttribute("id");
		
		MemberService mservice = MemberService.getInstance();
		Member m = (Member)mservice.memberSearch(rid);
		
		if(m == null)
		{
			
		}
		else
		{
			BankService service = BankService.getInstance();
			money = service.withdraw(id, money);
			if( money < 0)
			{
				
			}
			else
			{
				service.deposit(rid, money);
				req.setAttribute("money", money);
				HttpUtil.forward(req, resp, "/result/transitOutput.jsp");
			}
		}
	}

}
