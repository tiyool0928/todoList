package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import ServletExam.*;

public class memberDao {


	public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/account?serverTimezone=UTC", "root", "cs1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public void insertMember (account m) {
		Connection con = this.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement("insert into member values(?,?,?)");

			pstmt.setString(1, m.getId());
			pstmt.setString(2, m.getPassword());
			pstmt.setInt(3, m.getMoney());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void Login (account id, account pwd) {
		Connection con = this.getConnection();
		try {
			ResultSet rs = stmt.executeQuery("select * from member where id='" + id + "' and passwd= '" + pwd + "'");
			if(rs.next()) {
				session.setAttribute("userid", null);
				session.setAttribute("username", null);
				session.setAttribute("isAdmin", null);
				
				session.setAttribute("userid", id);
				if(id.equals("aaa"))
				{
					session.setAttribute("isAdmin", "true");
				}
				response.sendRedirect("adminMain.jsp");
			}
			else
			{
				response.sendRedirect("index.jsp");
			}
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	public void depositMoney (account m) {
		Connection con = this.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement("update member set where ");
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
