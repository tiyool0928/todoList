package biz;

import ServletExam.account;
import dao.memberDao;

public class memberService {

	memberDao dao = new memberDao();

	public void insertMember(account m) {
		dao.insertMember(m);
	}
	public void Login(account id,account pwd) {
		dao.Login(id,pwd);
	}
	public void depositMoney(account m) {
		dao.depositMoney(m);
	}
}

