package ServletExam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class depositServlet extends HttpServlet{
	ServletContext sc;
	static account[] members;
	int i;
	
	public void init(ServletConfig config) {
		sc=config.getServletContext();
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		int Money = Integer.parseInt(req.getParameter("depositM"));
		
		account[] memberList = (account[])sc.getAttribute("members");
		HttpSession session=req.getSession();
		String id=(String)session.getAttribute("loginId");
		
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		//out.print(id+"");
		
		if(Money == 0) {
			String errmsg = "�ݾ��� �������ֽʽÿ�.";
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/depositInput.jsp");
			rd.forward(req, resp);
		}
		
		for(i=0; i<account.count; i++) {
			if(memberList[i].getId().equals(id)){
				
			memberList[i].deposit(Money);
			req.setAttribute("id", id);
			req.setAttribute("Money", Money);
			
			RequestDispatcher rd = sc.getRequestDispatcher("/depositOutput.jsp");
			rd.forward(req, resp);
			break;
		}
		}
	}
}