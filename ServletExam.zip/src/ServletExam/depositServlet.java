package ServletExam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class depositServlet extends HttpServlet{
	ServletContext sc;
	static account[] members;
	int i;
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String inputMoney = req.getParameter("depositM");
		sc=req.getSession().getServletContext();
	
		int Money = Integer.parseInt(inputMoney);
		account[] memberList = (account[])sc.getAttribute("members");
		String id=(String)sc.getAttribute("id");
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		//out.print(id+"");
		
		if(Money == 0) {
			String errmsg = "금액을 정해주세요."; // set amount of money
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/depositInput.jsp");
			rd.forward(req, resp);
		}
		
		for(i=0; i<account.count; i++) {
			if(memberList[i].getId().equals(id)){
			int inputM = memberList[i].getMoney()+Money;
			memberList[i].setMoney(inputM);
			
			String inputMn=Integer.toString(inputM);
			
			sc.setAttribute("inputMoney", inputMoney);
			sc.setAttribute("finalMoney", inputMn);
			
			/*out.print(memberList[i].getId()+" 고객님의 계좌로"+inputMoney+"원이 입금되었습니다.");
			out.print("잔액은 "+inputM+"원 입니다.");*/
			
			RequestDispatcher rd = sc.getRequestDispatcher("/depositOutput.jsp");
			rd.forward(req, resp);
			break;
		}
		}
	}
}