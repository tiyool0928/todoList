package ServletExam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class indexLogin extends HttpServlet{
	ServletContext sc;
	String adID;
	String adPwd;
	static account[] members;
	int i;
	
	public void init(ServletConfig config) throws ServletException{
		sc = config.getServletContext();
		adID = sc.getInitParameter("adminId");
		adPwd = sc.getInitParameter("adminPassword");
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String inputId = req.getParameter("loginId");
		String inputPwd = req.getParameter("loginPasswd");
		sc=req.getSession().getServletContext();
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		account[] newMember = (account[])sc.getAttribute("members");
		
		if(inputId.equals(adID) && inputPwd.equals(adPwd)) {
			
			req.setAttribute("id", inputId);
			RequestDispatcher rd = sc.getRequestDispatcher("/adminMain.jsp");
			rd.forward(req, resp);
		}
		else if(inputId.equals(adID)) {
			String errmsg = "Admin's Password is Wrong";
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/index.jsp");
			rd.forward(req, resp);
		}
		else {
			for(i=0; i<account.count; i++)
			{
				if(newMember[i].getId().equals(inputId) && newMember[i].getPassword().equals(inputPwd))
				{
					HttpSession session = req.getSession();
					session.setAttribute("loginId", inputId);
					RequestDispatcher rd = sc.getRequestDispatcher("/main.jsp");
					rd.forward(req, resp);
					break;
				}
				else if(newMember[i].getId().equals(inputId))
				{
					String errmsg = "Password is Wrong";
					req.setAttribute("errorMsg",errmsg);
					RequestDispatcher rd = sc.getRequestDispatcher("/index.jsp");
					rd.forward(req, resp);
					break;
				}
			}
			if(i == account.count) {
				String errmsg = "ID is not exists";
				req.setAttribute("errorMsg",errmsg);
				RequestDispatcher rd = sc.getRequestDispatcher("/index.jsp");
				rd.forward(req, resp);
			}
		}
	}

}
