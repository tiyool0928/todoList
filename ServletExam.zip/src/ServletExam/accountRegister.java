package ServletExam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class accountRegister extends HttpServlet{
	ServletContext sc;
	account [] members;
	
	public void init(ServletConfig config) throws ServletException{
		members = new account[10];
	}
	
	public void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException 
	{
		String inputId = req.getParameter("registerId");
		String inputPwd = req.getParameter("registerPasswd");
		sc = req.getSession().getServletContext();
		int i;
		
		account newMember = new account(inputId,inputPwd);
		
		members[account.count-1] = newMember;
		
		sc.setAttribute("members", members);
		
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		for(i=0; i<account.count-1; i++)
		{
			if(members[i].getId().equals(inputId)) {
				account.count--;
				String error = "���̵� �ߺ��˴ϴ�.";
				req.setAttribute("errorMsg", error);
				RequestDispatcher rd = req.getRequestDispatcher("accountRegister.jsp");
				rd.forward(req, resp);
				break;
			}
		}
		out.print("<html><head></head>");
		out.print("<body>" + inputId +"�� ���°� �����Ǿ����ϴ�.<br>");
		out.print("<a href='adminMain.jsp'>�������� �̵�<a></body>");
		out.print("</html>");
		out.close();
	}

}
