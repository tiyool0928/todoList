package ServletExam;

public class account {
	private String id;
	private String password;
	int Money =0;
	static int count = 0;

	public account(String tId, String tPwd) {
		id = tId;
		password= tPwd;
		Money = 0;
		count++;
	}
	
	public String getId() {
		return this.id;
	}

	public void SetId(String tId) {
		id = tId;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String tPwd) {
		password = tPwd;
	}
	
	public int getMoney() {
		return this.Money;
	}
	
	public void setMoney(int tMoney) {
		Money = tMoney;
	}
	
}
