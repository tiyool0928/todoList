package ServletExam;

public class account {
	private String id;
	private String password;
	private int Money =0;
	public static int count = 0;

	public account() {

	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getMoney() {
		return Money;
	}

	public void setMoney(int Money) {
		this.Money = Money;
	}
	
	public void deposit(int Money) {
		this.Money += Money;
	}
	public boolean withdraw(int Money) {
		if(this.Money < Money)
			return false;
		
		this.Money -= Money;
		return true;
	}
	public int query() {
		return this.Money;
	}
}
