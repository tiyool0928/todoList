package ServletExam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class transferServlet extends HttpServlet{
	ServletContext sc;
	static account[] members;
	int i;
	
	public void init(ServletConfig config) {
		sc=config.getServletContext();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String inputId = (String)req.getParameter("transferId");
		int Money = Integer.parseInt(req.getParameter("transferM"));
	
		account[] memberList = (account[])sc.getAttribute("members");
		HttpSession session=req.getSession();
		String id=(String)session.getAttribute("loginId");
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		/*for(i=0; i<account.count; i++)
		{
			if(memberList[i].getId().equals(inputId)) {

				req.setAttribute("receiveId", inputId);
				req.setAttribute("Money", Money);
				
				RequestDispatcher rd = sc.getRequestDispatcher("/transferOutput.jsp");
				rd.forward(req, resp);
				break;
			}
			else if(memberList[i].getId().equals(id) && Money > memberList[i].getMoney()) {
			String errmsg = "�ܾ��� �����մϴ�."; 
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/transferInput.jsp");
			rd.forward(req, resp);
			break;
			}
		}*/

		for(i=0; i<account.count; i++)
		{
			
			if(memberList[i].getId().equals(inputId)) {
				
				for(int j=0; j<account.count; j++) {
					
					if(memberList[j].getId().equals(id) && Money <= memberList[j].getMoney())
					{
						memberList[i].deposit(Money);
						memberList[j].withdraw(Money);
						req.setAttribute("receiveId", inputId);
						//req.setAttribute("senderId", id);
						req.setAttribute("Money", Money);
						req.setAttribute("totalMoney", memberList[j].query());
						
						RequestDispatcher rd = sc.getRequestDispatcher("/transferOutput.jsp");
						rd.forward(req, resp);
						return;
					}
					else if(memberList[j].getId().equals(id))
					{
						String errmsg =  "�ܾ��� �����մϴ�.";
						req.setAttribute("errorMsg",errmsg);
						RequestDispatcher rd = sc.getRequestDispatcher("/transferInput.jsp");
						rd.forward(req, resp);
					}
				}
				
				/*RequestDispatcher rd = sc.getRequestDispatcher("/transferOutput.jsp");
				rd.forward(req, resp);
				break;*/
			}
		}
			String errmsg = inputId+"�������� �������� �ʽ��ϴ�.";
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/transferInput.jsp");
			rd.forward(req, resp);
	}
}