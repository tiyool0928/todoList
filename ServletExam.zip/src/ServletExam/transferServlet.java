package ServletExam;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class transferServlet extends HttpServlet{
	ServletContext sc;
	static account[] members;
	int i;

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String inputId = (String)req.getParameter("transferId");
		String inputMoney = (String)req.getParameter("transferM");
		
		sc=req.getSession().getServletContext();
		
		int Money = Integer.parseInt(inputMoney);
		account[] memberList = (account[])sc.getAttribute("members");
		String id=(String)sc.getAttribute("id");
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		for(i=0; i<account.count; i++)
		{
			if(memberList[i].getId().equals(id)) {
				int inputM = memberList[i].getMoney()-Money;
				
				memberList[i].setMoney(inputM);
				
				String inputMn=Integer.toString(inputM);
				sc.setAttribute("InputMoney", inputMoney);
				sc.setAttribute("finalMoney", inputMn);
				
				RequestDispatcher rd = sc.getRequestDispatcher("/transferOutput.jsp");
				rd.forward(req, resp);
			}
			else if(memberList[i].getId().equals(id) && Money > memberList[i].getMoney()) {
			String errmsg = "잔액이 부족합니다."; // set amount of money
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/transferInput.jsp");
			rd.forward(req, resp);
			break;
			}
		}
		if (i == account.count)
		{
			String errmsg = inputId+"고객님이 존재하지 않습니다."; // set amount of money
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/transferInput.jsp");
			rd.forward(req, resp);
		}
	}
}